=== Medic - Health and Medical Clinic WordPress Theme ===

Contributors: MhrTheme
Tags: hospital, medical, clinic, elementor, website, theme, wordpress, woocommerce, doctor, testimonial, appointment, contact, faq, banner, slider, department, services, shop, product, equipment

Requires at least: 4.5
Tested up to: 5.9.2
Requires PHP: 5.6
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Medic is a wordpress theme that is based on hospitals, clinics, medical websites.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Medic includes support for WooCommerce, Elementor Website Builder & Contact Form 7.

= 1.0.0 =
* Initial release
