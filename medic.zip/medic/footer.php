<?php
/**
 * The template for displaying the footer
 *
 * @package Medic
 */


	get_template_part( 'template-parts/content', 'footer' ); ?>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
