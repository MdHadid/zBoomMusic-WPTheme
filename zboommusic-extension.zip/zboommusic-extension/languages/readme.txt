You can see this blog for traslation:

https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/

Thank you for your contribution.
