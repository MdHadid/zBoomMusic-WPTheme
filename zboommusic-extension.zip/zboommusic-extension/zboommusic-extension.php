<?php
/**
 * Plugin Name:     zBoomMusic Extension
 * Plugin URI:        #
 * Description:       This plugin is used only for zBoomMusic Theme.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            MhrThemes
 * Author URI:        https://mhrthemes.000webhostapp.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zboommusic-extension
 * Domain Path:       /languages
 */

if(file_exists(dirname(__File__).'/includes/framework/ReduxCore/framework.php')) {
    require_once(dirname(__File__).'/includes/framework/ReduxCore/framework.php');
}

if(file_exists(dirname(__File__).'/includes/framework/sample/config.php')) {
    require_once(dirname(__File__).'/includes/framework/sample/config.php');
} 

function zboommusic_extension() {

    // Custom post types
	register_post_type('zboomslider', array(
		
		'labels'   => array(
		  
		  'name'         => 'Sliders',
			'add_new_item' => 'Add New Slider'
		  ),
		  
		'public'        => true,
		'supports'      => array('title','thumbnail'),
	  'menu_position' => 7,
	  'menu_icon'     => 'dashicons-format-gallery'
		
	));

	register_post_type('zboomblocks', array(
		
		'labels'   => array(
			  
			'name'      => 'Blocks',
			'add_new_item' => __('Add New Block','zboommusic')
			),
			  
			'public'   => true,
			'supports' => array('title','editor'),
		'menu_position' => 8,
		'menu_icon'     => 'dashicons-screenoptions'

	));

	register_post_type('zboomgallery', array(
	  
	  'labels'   => array(
		  
		'name'         => 'Gallery',
		'add_new_item' => __('Add New Gallery Item','zboommusic')
		),
		  
		'public'        =>  true,
		'supports'      => array('title', 'editor', 'thumbnail'),
		'menu_position' => 9,
		'menu_icon'     => 'dashicons-images-alt2'
	  
	));
}

add_action('init', 'zboommusic_extension');
