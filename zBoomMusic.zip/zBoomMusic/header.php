<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package zBoomMusic
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<style type="text/css">

		<?php 
		    global $zboommusic;
		    echo $zboommusic['custom-css'];
        ?>

        body {
            background-color: <?php echo $zboommusic['body-background']['background-color']; ?>
                !important;
            background-image: url(<?php echo $zboommusic['body-background']['background-image'];?>) !important;
            background-repeat: <?php echo $zboommusic['body-background']['background-repeat']; ?> !important;
            background-attachment: <?php echo $zboommusic['body-background']['background-attachment']; ?> !important;
            background-position: <?php echo $zboommusic['body-background']['background-position']; ?> !important;
            background-size: <?php echo $zboommusic['body-background']['background-size']; ?> !important;
        }

        h1, h2, h3, h4. h5, h6 {
        	color: <?php echo $zboommusic['title-color']; ?>;
        }

        p {
        	color: <?php echo $zboommusic['paragraph-color']; ?> !important;
        }

        nav .wrap-nav {
            border-top: <?php echo $zboommusic['menu-border']['border-top']; ?> !important;
            border-bottom: <?php echo $zboommusic['menu-border']['border-bottom']; ?> !important;
            border-right: <?php echo $zboommusic['menu-border']['border-right']; ?> !important;
            border-left: <?php echo $zboommusic['menu-border']['border-left']; ?> !important;
            border-style: <?php echo $zboommusic['menu-border']['border-style']; ?> !important;
            border-color: <?php echo $zboommusic['menu-border']['border-color']; ?> !important;
        }

        header .wrap-header {
        	height: <?php echo $zboommusic['header-dimensions']['height']; ?> !important;
        	width: <?php echo $zboommusic['header-dimensions']['width']; ?> !important;
        }

	</style>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'zboommusic' ); ?></a>

	<header id="masthead" class="site-header">
		<div class="wrap-header zerogrid">
			<div id="logo">
				<?php if( $zboommusic['logo-visible'] == 1 ) : ?>
					<a href="<?php echo esc_url( home_url('/') ); ?>">
						<img src="
							<?php 
							    global $zboommusic;
							    echo $zboommusic ['upload-logo']['url']; 
							?>
						">
				    </a>
			    <?php endif; ?>
			</div><br/><br/><br/>

			<div class="site-branding">
				<?php
				if ( is_front_page() && is_home() ) :
					?>
					<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php
				else :
					?>
					<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
					<?php
				endif;
				$zboommusic_description = get_bloginfo( 'description', 'display' );
				if ( $zboommusic_description || is_customize_preview() ) :
					?>
					<p class="site-description"><?php echo $zboommusic_description; /* WPCS: xss ok. */ ?></p>
				<?php endif; ?>
			</div><!-- .site-branding -->
			
			<div id="search">
				<form method="get" action="<?php echo esc_url( home_url('/') ); ?>">
				<input type="text" name="s" value="Search..." onfocus="if (this.value == &#39;Search...&#39;) {this.value = &#39;&#39;;}" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Search...&#39;;}">
			    </form>
			</div>
		</div>

		<nav>
			<div class="wrap-nav zerogrid">
				<div class="menu">
					<?php wp_nav_menu(array(
		                'theme_location' => 'main-menu'
		            )); ?>
				</div>	
			</div>
		</nav>
	</header><!-- #masthead -->

	<div id="content" class="site-content">
