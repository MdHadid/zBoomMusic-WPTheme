<?php
/**
 * zBoomMusic functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package zBoomMusic
 */

if ( ! function_exists( 'zboommusic_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function zboommusic_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on zBoomMusic, use a find and replace
		 * to change 'zboommusic' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'zboommusic', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.

		// Menu register
		register_nav_menus(array(
		    'main-menu'           => __('Primary menu' , 'zboommusic'),
		    'footer-post-menu'    => __('Footer post menu' , 'zboommusic'),
		    'footer-contact-menu' => __('Footer contact menu' , 'zboommusic'),
		    'sidebar-event-menu'  => __('Sidebar event menu' , 'zboommusic')
		  ));

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'zboommusic_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		/*add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );*/
	}
endif;

add_action( 'after_setup_theme', 'zboommusic_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function zboommusic_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'zboommusic_content_width', 640 );
}
add_action( 'after_setup_theme', 'zboommusic_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

// Content Read More
function read_more($limit) {
  $post_content = explode(' ' , get_the_content()); 
  $less_content = array_slice($post_content, 0, $limit);
  echo implode(' ', $less_content);
}

// Create sidebar
function zboom_sidebar() {
    register_sidebar(array(
      'name'          => __('Right Sidebar', 'zboommusic'),
      'description'   => __('You can add right sidebar widgets from here', 'zboommusic'),
      'id'            => 'right-sidebar',
      'before_widget' => '<div class="box">',
      'after_widget'  => '</div></div></div>',
      'before_title'  => '<div class="heading"><h2>',
      'after_title'   => '</h2></div><div class="content"><div class="list">'
  ));

    register_sidebar(array(
      'name'          => __('Left Sidebar', 'zboommusic'),
      'description'   => __('You can add left sidebar widgets from here', 'zboommusic'),
      'id'            => 'left-sidebar',
      'before_widget' => '<div class="box">',
      'after_widget'  => '</div></div></div>',
      'before_title'  => '<div class="heading"><h2>',
      'after_title'   => '</h2></div><div class="content"><div class="list">'
  ));

    register_sidebar(array(
      'name'          => __('Footer Widgets', 'zboommusic'),
      'description'   => __('You can add footer widgets from here', 'zboommusic'),
      'id'            => 'footer-widget',
      'before_widget' => '<div class="col-1-4"><div class="wrap-col"><div class="box">',
      'after_widget'  => '</div></div></div></div>',
      'before_title'  => '<div class="heading"><h2>',
      'after_title'   => '</h2></div><div class="content">'
  ));

    register_sidebar(array(
      'name'          => __('Contact Right Sidebar', 'zboommusic'),
      'description'   => __('You can add contact right sidebar from here', 'zboommusic'),
      'id'            => 'contact-right-sidebar',
      'before_widget' => '<div class="box">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="heading"><h2>',
      'after_title'   => '</h2></div><div class="content">'
  ));

    register_sidebar(array(
      'name'          => __('Contact Left Sidebar', 'zboommusic'),
      'description'   => __('You can add contact left sidebar from here', 'zboommusic'),
      'id'            => 'contact-left-sidebar',
      'before_widget' => '<div class="box">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="heading"><h2>',
      'after_title'   => '</h2></div><div class="content">'
  ));
}

add_action('widgets_init', 'zboom_sidebar');

/**
 * Enqueue scripts and styles.
 */
function zboommusic_scripts() {
    
    wp_enqueue_style( 'zboommusic-fonts', get_template_directory_uri() . '/assets/fonts/css/all.css' );

	wp_enqueue_style( 'zboommusic-responsive-slides', get_template_directory_uri() . '/assets/css/responsive-slides.css' );

	wp_enqueue_style( 'zboommusic-responsive', get_template_directory_uri() . '/assets/css/responsive.css' );

	wp_enqueue_style( 'zboommusic-zerogrid', get_template_directory_uri() . '/assets/css/zerogrid.css' );

	wp_enqueue_style( 'zboommusic-style', get_stylesheet_uri() );

	wp_enqueue_script('jquery');

	wp_enqueue_script( 'zboommusic-responsive-slides', get_template_directory_uri() . '/assets/js/responsive-slides.js', array(), '20151215', true );

	wp_enqueue_script( 'zboommusic-script', get_template_directory_uri() . '/assets/js/script.js', array(), '20151215', true );

	wp_enqueue_script( 'zboommusic-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'zboommusic-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'zboommusic_scripts' );

/**
 * Enqueue supplemental block editor styles.
 */
function zBoomMusic_block_editor_styles() {

	$css_dependencies = array();

	// Enqueue the editor styles.
	wp_enqueue_style( 'zBoomMusic-block-editor-styles', get_theme_file_uri( '/assets/css/editor-style-block.css' ), $css_dependencies, wp_get_theme()->get( 'Version' ), 'all' );
	wp_style_add_data( 'zBoomMusic-block-editor-styles', 'rtl', 'replace' );

	// Add inline style from the Customizer.
	wp_add_inline_style( 'zBoomMusic-block-editor-styles', zBoomMusic_get_customizer_css( 'block-editor' ) );

	// Add inline style for non-latin fonts.
	wp_add_inline_style( 'zBoomMusic-block-editor-styles', zBoomMusic_Non_Latin_Languages::get_non_latin_css( 'block-editor' ) );

	// Enqueue the editor script.
	wp_enqueue_script( 'zBoomMusic-block-editor-script', get_theme_file_uri( '/assets/js/editor-script-block.js' ), array( 'wp-blocks', 'wp-dom' ), wp_get_theme()->get( 'Version' ), true );
}

add_action( 'enqueue_block_editor_assets', 'zBoomMusic_block_editor_styles', 1, 1 );

/**
 * Enqueue classic editor styles.
 */
function zBoomMusic_classic_editor_styles() {

	$classic_editor_styles = array(
		'/assets/css/editor-style-classic.css',
	);

	add_editor_style( $classic_editor_styles );

}

add_action( 'init', 'zBoomMusic_classic_editor_styles' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Required Plugins.
 */
require get_template_directory() . '/inc/plugins/init.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}
