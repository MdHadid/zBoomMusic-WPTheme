<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package zBoomMusic
 */
?>

<div class="wrap-col">
	<?php dynamic_sidebar('right-sidebar'); ?>
</div>
