<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package zBoomMusic
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<!--------------Content--------------->
			<section id="content">
				<div class="wrap-content zerogrid">
					<div class="row block03">
						<div class="col-3-3">
							<div class="wrap-col">
								<div class="text-404">
									<?php global $zboommusic; ?>
									<h1><?php echo $zboommusic['404-page-text'][0] ?></h1><br>
									<p><?php echo $zboommusic['404-page-text'][1] ?></p><br>
									<?php if($zboommusic['404-page-text'][2]) : ?>
									<p><?php echo $zboommusic['404-page-text'][2] ?></p><br>
								    <?php endif; ?>
								    <?php if($zboommusic['404-page-text'][3]) : ?>
									<p><?php echo $zboommusic['404-page-text'][3] ?></p><br>
									<?php endif; ?>									
									<p><a href="<?php echo esc_url( home_url('/') ); ?>">Go Back Homepage</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer();
