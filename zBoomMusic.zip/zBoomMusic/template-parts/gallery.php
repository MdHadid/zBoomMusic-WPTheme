<?php

/*

Template Name: Gallery

*/

?>

<?php get_header(); ?>

<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<?php global $zboommusic; ?>
			<?php if( $zboommusic['opt-select'] == 1 ) : ?>
				<?php
	                $galleryitems=new WP_Query(array(
				       'post_type' => 'zboomgallery',
				       'posts_per_page' => 8
				    ));
	            ?>
	            <?php while($galleryitems->have_posts()) : $galleryitems->the_post(); ?>
	            <div class="col-1-4">
					<div class="wrap-col">
						<article>
							<?php the_post_thumbnail(); ?>
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						</article>
					</div>
				</div>
				<?php endwhile; ?>
		    <?php endif; ?>

		    <?php if( $zboommusic['opt-select'] == 2 ) : ?>
				<?php
	                $galleryitems=new WP_Query(array(
				       'post_type' => 'zboomgallery',
				       'posts_per_page' => 4
				    ));
	            ?>
	            <?php while($galleryitems->have_posts()) : $galleryitems->the_post(); ?>
	            <div class="col-1-4">
					<div class="wrap-col">
						<article>
							<?php the_post_thumbnail(); ?>
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						</article>
					</div>
				</div>
				<?php endwhile; ?>
		    <?php endif; ?>
		</div>
	</div>
</section>

<?php get_footer(); ?>