<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package zBoomMusic
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="wrap-footer zerogrid">
			<div class="row block09">
	            <?php dynamic_sidebar('footer-widget'); ?>
			</div>
			<?php global $zboommusic; ?>
			<?php if( $zboommusic['footer-social'] == 1 ) : ?>
			<div class="social">
				<h1>Lets Socialize</h1>
				<?php if ( $zboommusic['social-links']['1'] ) : ?>
					<?php if( $zboommusic['select-socials'][0] == 1 || $zboommusic['select-socials'][1] == 1 || $zboommusic['select-socials'][2] == 1 || $zboommusic['select-socials'][3] == 1 || $zboommusic['select-socials'][4] == 1 ) :  ?>
						<a href="<?php echo $zboommusic['social-links']['1']; ?>"><i class="fab fa-facebook-f"></i></a>
					<?php endif; ?>
	            <?php endif; ?>
			    <?php if ( $zboommusic['social-links']['2'] ) : ?>
			    	<?php if( $zboommusic['select-socials'][0] == 2 || $zboommusic['select-socials'][1] == 2 || $zboommusic['select-socials'][2] == 2 || $zboommusic['select-socials'][3] == 2 || $zboommusic['select-socials'][4] == 2 ) :  ?>
						<a href="<?php echo $zboommusic['social-links']['2']; ?>"><i class="fab fa-youtube"></i></a>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ( $zboommusic['social-links']['3'] ) : ?>
					<?php if( $zboommusic['select-socials'][0] == 3 || $zboommusic['select-socials'][1] == 3 || $zboommusic['select-socials'][2] == 3 || $zboommusic['select-socials'][3] == 3 || $zboommusic['select-socials'][4] == 3 ) :  ?>
						<a href="<?php echo $zboommusic['social-links']['3']; ?>"><i class="fab fa-linkedin"></i></a>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ( $zboommusic['social-links']['4'] ) : ?>
					<?php if( $zboommusic['select-socials'][0] == 4 || $zboommusic['select-socials'][1] == 4 || $zboommusic['select-socials'][2] == 4 || $zboommusic['select-socials'][3] == 4 || $zboommusic['select-socials'][4] == 4 ) :  ?>
						<a href="<?php echo $zboommusic['social-links']['4']; ?>"><i class="fab fa-twitter"></i></a>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ( $zboommusic['social-links']['5'] ) : ?>
					<?php if( $zboommusic['select-socials'][0] == 5 || $zboommusic['select-socials'][1] == 5 || $zboommusic['select-socials'][2] == 5 || $zboommusic['select-socials'][3] == 5 || $zboommusic['select-socials'][4] == 5 ) :  ?>
	                    <a href="<?php echo $zboommusic['social-links']['5']; ?>"><i class="fab fa-skype"></i></a>
					<?php endif; ?>
				<?php endif; ?>
			</div>
	        <?php endif; ?>
			<div class="row copyright">
				<p>
					<?php 
					  echo $zboommusic['copyright-text']; 
		            ?>
	            </p>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
